%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%       Dr.Tummala.S.L.V.Ayyarao
%% https://scholar.google.co.in/citations?user=X7i25FAAAAAJ&hl=en&oi=sra
%% GMR Institute of Technology, India
%% Ayyarao, TummalaS LV, N. S. S. RamaKrishna, Rajvikram Madurai Elavarasam, Nishanth Polumahanthi, M. Rambabu, Gaurav Saini, Baseem Khan, and Bilal Alatas. "War Strategy Optimization Algorithm: A New Effective Metaheuristic Algorithm for Global Optimization." IEEE Access (2022).
%% https://ieeexplore.ieee.org/abstract/document/9718247
%% Code developed by Tummala.S.L.V.Ayyarao
%% Ayyarao, Tummala SLV, and Polamarasetty P. Kumar. "Parameter estimation of solar PV models with a new proposed war strategy optimization algorithm." International Journal of Energy Research (2022).
%% https://onlinelibrary.wiley.com/doi/abs/10.1002/er.7629
%% Improved version of the code will be updated soon                
%%  Parameter extraction of SDM
% close all
clear
clc
format long;
Solidiers_no=50; % Number of Soldiers
Max_iteration=1000; % Maximum numbef of iterations
global V Ie Im
% Objective Function
tic
fobj=@single_dd;
lb=[0 0 0 0 1];
ub=[1 1 100 0.5 2];
dim=5;
BEst=zeros(1,10);
BESTT1=inf;
for i=1:10
i

[Best_score,Best_pos,WSO_cg_curve]=WSO(Solidiers_no,Max_iteration,lb,ub,dim,fobj);
BEst(i)=Best_score;
if Best_score<BESTT1
    BESTT1 = Best_score;
    BESTT2=Best_pos;
end
% BEst(i)=min(PSO_cg_curve);
end
toc
S=std(BEst)
A=mean(BEst)
B=min(BEst)
single_dd(BESTT2)
% figure(1)

figure(1)

semilogy(WSO_cg_curve,'Color','b')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
% % % % 
axis tight
grid on
box on

figure(2)
plot(V,Im,'LineWidth',2)
hold on
plot(V,Ie,'>','LineWidth',2,'MarkerFaceColor','black')
xlabel('Voltage')
ylabel('Current')
legend('measured','estimated')

figure(3)
plot(V, V.*Im,'LineWidth',2)
hold on
plot(V,V.*Ie,'>','LineWidth',2)
xlabel('Voltage')
ylabel('Power')
