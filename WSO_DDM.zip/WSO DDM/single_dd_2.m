%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%       Dr.Tummala.S.L.V.Ayyarao
%% https://scholar.google.co.in/citations?user=X7i25FAAAAAJ&hl=en&oi=sra
%% GMR Institute of Technology, India
%% Ayyarao, TummalaS LV, N. S. S. RamaKrishna, Rajvikram Madurai Elavarasam, Nishanth Polumahanthi, M. Rambabu, Gaurav Saini, Baseem Khan, and Bilal Alatas. "War Strategy Optimization Algorithm: A New Effective Metaheuristic Algorithm for Global Optimization." IEEE Access (2022).
%% https://ieeexplore.ieee.org/abstract/document/9718247
%% Code developed by Tummala.S.L.V.Ayyarao
%% Ayyarao, Tummala SLV, and Polamarasetty P. Kumar. "Parameter estimation of solar PV models with a new proposed war strategy optimization algorithm." International Journal of Energy Research (2022).
%% https://onlinelibrary.wiley.com/doi/abs/10.1002/er.7629
%% Ayyarao, Tummala SLV. "Parameter estimation of solar PV models with quantum-based avian navigation optimizer and Newton–Raphson method." Journal of Computational Electronics (2022): 1-19.
%%  Parameter extraction of DDM
function J = single_dd_2(X)
global V Ie Im
% k=1.38064852*10^(-23);
% q=1.60217646*10^(-19);
% Iph_e=X(1);
% % Iph=0.7608;
% Id_e=X(2);
% % Id=0.3223*10^-6;
% N=1.4837;
% Rsh_e=X(3);
% % Rsh=1/0.0186;
% % Rs=0.0364;
% Rs_e=X(4);
% T=306.15;
% alpha_e=X(5);
% % alpha=N;
J1=0;
Im=[0.764 0.762 0.7605 0.7605 0.76 0.759 0.757 0.757 0.7555 0.754 0.7505 0.7465 0.7385 0.728 0.7065 0.6755 0.632 0.573 0.499 0.413 0.3165 0.212 0.1035 -0.01 -0.123 -0.21];
V=[-0.2057 -0.1291 -0.0588 0.0057 0.0646 0.1185 0.1678 0.2132 0.2545 0.2924 0.3269 0.3585 0.3873 0.4137 0.4373 0.4590 0.4784 0.496 0.5119 0.5265 0.5398 0.5521 0.5633 0.5736 0.5833 0.59];
for i=1:26
Ie(i)=Ipv_newton_dd(X,V(i),Im(i));
if isnan(Ie(i))
    Ie(i)=100;
end
e=(Im(i)-Ie(i))^2;
J1=J1+e;
end
J=sqrt(1/26*J1);
end
