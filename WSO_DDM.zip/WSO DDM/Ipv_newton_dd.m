%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%       Dr.Tummala.S.L.V.Ayyarao
%% https://scholar.google.co.in/citations?user=X7i25FAAAAAJ&hl=en&oi=sra
%% GMR Institute of Technology, India
%% Ayyarao, TummalaS LV, N. S. S. RamaKrishna, Rajvikram Madurai Elavarasam, Nishanth Polumahanthi, M. Rambabu, Gaurav Saini, Baseem Khan, and Bilal Alatas. "War Strategy Optimization Algorithm: A New Effective Metaheuristic Algorithm for Global Optimization." IEEE Access (2022).
%% https://ieeexplore.ieee.org/abstract/document/9718247
%% Code developed by Tummala.S.L.V.Ayyarao
%% Ayyarao, Tummala SLV, and Polamarasetty P. Kumar. "Parameter estimation of solar PV models with a new proposed war strategy optimization algorithm." International Journal of Energy Research (2022).
%% https://onlinelibrary.wiley.com/doi/abs/10.1002/er.7629
%% Ayyarao, Tummala SLV. "Parameter estimation of solar PV models with quantum-based avian navigation optimizer and Newton�Raphson method." Journal of Computational Electronics (2022): 1-19.
%%  Parameter extraction of DDM
function x=Ipv_newton_dd(X,v,x0) 
%�newtonparam� input parameters =[Rs,Rsh,Io_GT,v,Ns,Vt_T,Iph_GT][INTERNAL VARIABLES ASSIGNED TO VARIABLES HERE] %%NEWTON RAPHSON SOLVING FOR 'XX' I.E. OUTPUT PANEL CURRENT BASED ON PANEL VOLTAGE AS INPUT
k=1.38064852e-23;
q=1.60217646e-19;
T=33+273.15;
Vt_stc=k*T/q;
Iph=X(1);Io1=X(2);Io2=X(3);Rsh=X(4);Rs=X(5);Ns1=X(6);Ns2=X(7);
f=@ (xx) Iph - xx -((v + Rs*xx)/Rsh) - Io1*1e-6*(exp((v + Rs*xx)/(Ns1*Vt_stc)) - 1)- Io2*1e-6*(exp((v + Rs*xx)/(Ns2*Vt_stc)) - 1); 
fd=@ (xx) - Rs/Rsh -(1/(Ns1*Vt_stc))*Io1*1e-6*Rs*exp((v + Rs*xx)/(Ns1*Vt_stc))-(1/(Ns2*Vt_stc))*Io2*1e-6*Rs*exp((v + Rs*xx)/(Ns2*Vt_stc))-1; 
N = 1000; eps = 1.e-9; % define max. no. iterations and error 
% maxval = 10000.0; % define value for divergence 
xx = x0; 
while (N>0) 
    xn = xx-f(xx)/fd(xx); 
    if abs(f(xn))<eps  
        x=xn;  
        return; 
    end
    N = N - 1; 
    xx = xn; 
end
x=xx;
end