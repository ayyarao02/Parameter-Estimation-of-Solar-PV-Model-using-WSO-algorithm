%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%       Dr.Tummala.S.L.V.Ayyarao
%% https://scholar.google.co.in/citations?user=X7i25FAAAAAJ&hl=en&oi=sra
%% GMR Institute of Technology, India
%% Ayyarao, TummalaS LV, N. S. S. RamaKrishna, Rajvikram Madurai Elavarasam, Nishanth Polumahanthi, M. Rambabu, Gaurav Saini, Baseem Khan, and Bilal Alatas. "War Strategy Optimization Algorithm: A New Effective Metaheuristic Algorithm for Global Optimization." IEEE Access (2022).
%% https://ieeexplore.ieee.org/abstract/document/9718247
%% Code developed by Tummala.S.L.V.Ayyarao
%% Ayyarao, Tummala SLV, and Polamarasetty P. Kumar. "Parameter estimation of solar PV models with a new proposed war strategy optimization algorithm." International Journal of Energy Research (2022).
%% https://onlinelibrary.wiley.com/doi/abs/10.1002/er.7629
%% Ayyarao, Tummala SLV. "Parameter estimation of solar PV models with quantum-based avian navigation optimizer and Newton–Raphson method." Journal of Computational Electronics (2022): 1-19.
%%  Parameter extraction of DDM
close all
clear
clc
format long;
warning('off','all')
warning
SearchAgents_no=50; % Number of search agents
global V Ie Im 

Max_iteration=1000; % Maximum numbef of iterations

fobj=@single_dd_2;
lb=[0 0 0 1 0 1 1];
ub=[1 1 1 100 0.5 2 2];
dim=7;
BEst=zeros(1,10);
BEst1=inf;
for i=1:1
    [Best_score,Best_pos,WSO_cg_curve]= WSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);
    
end
% S=std(BEst)
% A=mean(BEst)
% B=min(BEst)
single_dd_2(Best_pos);
figure(1)
semilogy(WSO_cg_curve,'Color','r')
xlabel('Iteration');
ylabel('Best score obtained so far');
% % % % 
axis tight
grid on
box on
figure(2)
plot(V,Im)
hold on
plot(V, Ie, '*')
xlabel('Current')
ylabel('Voltage')